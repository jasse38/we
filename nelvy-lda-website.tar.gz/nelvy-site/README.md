# Nelvy LDA — Website

Site oficial da Nelvy LDA — Informática & Segurança Electrônica.

## Instalar e correr localmente

```bash
npm install
npm run dev
```

Abre em: http://localhost:5173

## Build para produção

```bash
npm run build
```

Ficheiros gerados na pasta `dist/`

## Deploy no Vercel (gratuito)

1. Coloque este repositório no GitHub
2. Aceda a [vercel.com](https://vercel.com) → "Add New Project"
3. Importe o repositório do GitHub
4. Configurações (automáticas):
   - **Framework:** Vite
   - **Build command:** `npm run build`
   - **Output directory:** `dist`
5. Clique **Deploy**

## Deploy no Netlify (gratuito)

1. Aceda a [netlify.com](https://netlify.com) → "Add new site"
2. Ligue ao repositório GitHub
3. Clique **Deploy site**

## Contacto
- WhatsApp: +258 848 699 933
- Email: nelvy.geral@gmail.com
