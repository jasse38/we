# Nelvy LDA — Website

Site oficial da Nelvy LDA — Informática & Segurança Electrônica.

## Como usar

### Instalar dependências
```bash
npm install
```

### Desenvolvimento local
```bash
npm run dev
```
Abra http://localhost:5173

### Build para produção
```bash
npm run build
```
Os ficheiros ficam na pasta `dist/`

## Como fazer o deploy gratuito no Netlify

1. Faça upload deste repositório no GitHub
2. Aceda a [netlify.com](https://www.netlify.com) e crie uma conta gratuita
3. Clique em **"Add new site" → "Import an existing project"**
4. Ligue o repositório do GitHub
5. Configurações de build:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Clique em **Deploy site**

O site fica disponível 24/7 com um link `.netlify.app` gratuito.

## Contacto
- WhatsApp: +258 848 699 933
- Email: nelvy.geral@gmail.com
