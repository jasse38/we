import { Switch, Route, Router as WouterRouter } from "wouter";
import Home from "@/pages/Home";
import Produtos from "@/pages/Produtos";
import Servicos from "@/pages/Servicos";
import Galeria from "@/pages/Galeria";
import Contacto from "@/pages/Contacto";
import Sobre from "@/pages/Sobre";
import NotFound from "@/pages/not-found";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";

function Router() {
  return (
    <>
      <Navbar />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/produtos" component={Produtos} />
        <Route path="/servicos" component={Servicos} />
        <Route path="/galeria" component={Galeria} />
        <Route path="/contacto" component={Contacto} />
        <Route path="/sobre" component={Sobre} />
        <Route component={NotFound} />
      </Switch>
      <Footer />
      <WhatsAppFloat />
    </>
  );
}

export default function App() {
  return (
    <WouterRouter>
      <Router />
    </WouterRouter>
  );
}
